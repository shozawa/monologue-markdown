# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Dummy::Application.config.secret_token = '085fc255441bb506ade777e6f8c17ee52e0d0117e9ead73b3d67ef3daee4b40fea59d2fc4d1f3bb77a7d79a33792766e883d433417af9864d9373851a5c16159'
