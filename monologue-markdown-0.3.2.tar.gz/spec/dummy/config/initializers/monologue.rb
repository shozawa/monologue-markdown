Monologue.site_name            = "@jipiboily / Jean-Philippe Boily"
Monologue.site_subtitle        = "my own place online"
Monologue.site_url             = "http://jipiboily.com"
Monologue.disqus_shortname     = "jipiboily"
Monologue.meta_description     = "This is my personal blog about Rails, Monologue, programming, etc..."
Monologue.meta_keyword         = "rails, programming, monologue, ruby"
Monologue.twitter_username     = "jipiboily"
Monologue.twitter_locale       = "en" # "fr"
Monologue.facebook_like_locale = "en_US" # "fr_CA"
Monologue.google_plusone_locale = "en"
Monologue.admin_force_ssl       = false
Monologue.posts_per_page      = 10
# Monologue.layout               = "layouts/application"
# Monologue.google_analytics_id = "YOUR GA CODE"

Monologue.sidebar = ["latests_posts", "latests_tweets"]